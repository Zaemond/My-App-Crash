AviatorPredictor/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/aviatorpredictor/
│   │   │   ├── MainActivity.java
│   │   │   ├── WebSocketManager.java
│   │   │   └── CrashItem.java
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml
│   │   │   ├── drawable/
│   │   │   │   ├── circle_background_blue.xml
│   │   │   │   ├── button_gradient.xml
│   │   │   │   └── button_gradient_red.xml
│   │   │   └── values/
│   │   │       ├── colors.xml
│   │   │       ├── strings.xml
│   │   │       └── themes.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
└── build.gradle (project)