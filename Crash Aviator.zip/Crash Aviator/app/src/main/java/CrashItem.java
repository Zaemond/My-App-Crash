package com.example.aviatorpredictor;

public class CrashItem {
    private double value;
    private String time;
    private int index;

    public CrashItem(double value, String time, int index) {
        this.value = value;
        this.time = time;
        this.index = index;
    }

    public double getValue() {
        return value;
    }

    public String getTime() {
        return time;
    }

    public int getIndex() {
        return index;
    }
}