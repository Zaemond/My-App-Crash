package com.example.aviatorpredictor;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements WebSocketManager.WebSocketListener {

    private static final String TAG = "AviatorPredictor";

    private TextView textCurrent, textStatus, textTotal, textLastUpdate;
    private Button btnConnect;
    private LinearLayout historyItems;
    
    private List<CrashItem> crashHistory;
    private WebSocketManager webSocketManager;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeViews();
        setupClickListeners();
        
        webSocketManager = new WebSocketManager(this);
    }

    private void initializeViews() {
        textCurrent = findViewById(R.id.textCurrent);
        textStatus = findViewById(R.id.textStatus);
        textTotal = findViewById(R.id.textTotal);
        textLastUpdate = findViewById(R.id.textLastUpdate);
        btnConnect = findViewById(R.id.btnConnect);
        historyItems = findViewById(R.id.historyItems);
        
        crashHistory = new ArrayList<>();
    }

    private void setupClickListeners() {
        btnConnect.setOnClickListener(v -> toggleConnection());
    }

    private void toggleConnection() {
        if (webSocketManager.isConnected()) {
            webSocketManager.disconnect();
        } else {
            webSocketManager.connect();
        }
    }

    @Override
    public void onWebSocketOpen() {
        runOnUiThread(() -> {
            textStatus.setText("Connecté - En attente des données...");
            btnConnect.setText("Stop");
            btnConnect.setBackgroundResource(R.drawable.button_gradient_red);
            Toast.makeText(this, "Connexion établie", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onWebSocketMessage(String message) {
        try {
            JSONObject data = new JSONObject(message);
            String target = data.getString("target");
            
            if ("OnCrash".equals(target)) {
                JSONArray arguments = data.getJSONArray("arguments");
                JSONObject firstArg = arguments.getJSONObject(0);
                double crashValue = firstArg.getDouble("f");
                
                processCrashValue(crashValue);
            }
        } catch (JSONException e) {
            Log.e(TAG, "Erreur d'analyse: " + e.getMessage());
        }
    }

    private void processCrashValue(double crashValue) {
        String timestamp = timeFormat.format(new Date());
        
        CrashItem crashItem = new CrashItem(
            crashValue,
            timestamp,
            crashHistory.size() + 1
        );
        
        crashHistory.add(0, crashItem);
        
        if (crashHistory.size() > 10) {
            crashHistory.remove(crashHistory.size() - 1);
        }
        
        runOnUiThread(() -> {
            updateCurrentValue(crashValue);
            updateHistoryDisplay();
            updateStats();
            printJsonOutput(crashValue, timestamp);
        });
    }

    private void updateCurrentValue(double crashValue) {
        String displayText = String.format(Locale.getDefault(), "%.2fx", crashValue);
        textCurrent.setText(displayText);
        
        if (crashValue >= 2.0) {
            textCurrent.setTextColor(Color.parseColor("#4CAF50"));
        } else if (crashValue >= 1.5) {
            textCurrent.setTextColor(Color.parseColor("#FF9800"));
        } else {
            textCurrent.setTextColor(Color.parseColor("#F44336"));
        }
    }

    private void updateHistoryDisplay() {
        historyItems.removeAllViews();
        
        for (int i = 0; i < Math.min(crashHistory.size(), 10); i++) {
            CrashItem item = crashHistory.get(i);
            TextView historyView = createHistoryTextView(item);
            historyItems.addView(historyView);
            
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) historyView.getLayoutParams();
            params.setMargins(0, 0, 12, 0);
            historyView.setLayoutParams(params);
        }
    }

    private TextView createHistoryTextView(CrashItem item) {
        TextView textView = new TextView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        textView.setLayoutParams(params);
        
        String displayText = String.format(Locale.getDefault(), "%.2fx", item.getValue());
        textView.setText(displayText);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(14);
        textView.setPadding(20, 12, 20, 12);
        textView.setGravity(Gravity.CENTER);
        
        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setCornerRadius(25);
        
        if (item.getValue() >= 2.0) {
            background.setColor(Color.parseColor("#4CAF50"));
        } else if (item.getValue() >= 1.5) {
            background.setColor(Color.parseColor("#FF9800"));
        } else {
            background.setColor(Color.parseColor("#F44336"));
        }
        
        textView.setBackground(background);
        return textView;
    }

    private void updateStats() {
        textTotal.setText(String.format("Total: %d", crashHistory.size()));
        
        if (!crashHistory.isEmpty()) {
            String lastTime = crashHistory.get(0).getTime();
            textLastUpdate.setText(String.format("Dernier: %s", lastTime));
        }
    }

    private void printJsonOutput(double crashValue, String timestamp) {
        try {
            JSONObject jsonOutput = new JSONObject();
            jsonOutput.put("timestamp", new Date().toInstant().toString());
            jsonOutput.put("crashValue", crashValue);
            jsonOutput.put("displayTime", timestamp);
            jsonOutput.put("predictionIndex", crashHistory.size());
            jsonOutput.put("totalCount", crashHistory.size());
            
            JSONArray previousValues = new JSONArray();
            for (CrashItem item : crashHistory) {
                previousValues.put(item.getValue());
            }
            jsonOutput.put("previousValues", previousValues);
            
            String jsonString = jsonOutput.toString(2);
            Log.d(TAG, "Données Crash: " + jsonString);
            
        } catch (JSONException e) {
            Log.e(TAG, "Erreur création JSON: " + e.getMessage());
        }
    }

    @Override
    public void onWebSocketClosed(int code, String reason) {
        runOnUiThread(() -> {
            textStatus.setText("Déconnecté");
            btnConnect.setText("Start");
            btnConnect.setBackgroundResource(R.drawable.button_gradient);
            textCurrent.setText("1.00x");
            textCurrent.setTextColor(Color.WHITE);
            Toast.makeText(this, "Connexion fermée", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onWebSocketError(Exception ex) {
        runOnUiThread(() -> {
            textStatus.setText("Erreur de connexion");
            Toast.makeText(this, "Erreur: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webSocketManager != null) {
            webSocketManager.disconnect();
        }
    }
}