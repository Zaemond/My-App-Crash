package com.example.aviatorpredictor;

import android.util.Log;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

public class WebSocketManager {

    private static final String TAG = "WebSocketManager";
    
    private WebSocketClient webSocketClient;
    private WebSocketListener listener;
    private boolean isConnected = false;

    public interface WebSocketListener {
        void onWebSocketOpen();
        void onWebSocketMessage(String message);
        void onWebSocketClosed(int code, String reason);
        void onWebSocketError(Exception ex);
    }

    public WebSocketManager(WebSocketListener listener) {
        this.listener = listener;
    }

    public void connect() {
        try {
            // REPLACE WITH YOUR ACTUAL WEBSOCKET URL
            URI serverUri = URI.create("wss://eg.com/games-frame/sockets/crash?whence=50&fcountry=8&ref=1&gr=0&appGuid=games-web-master&lng=fr&access_token=YOUR_ACCESS_TOKEN");
            
            webSocketClient = new WebSocketClient(serverUri) {
                @Override
                public void onOpen(ServerHandshake handshakedata) {
                    Log.d(TAG, "WebSocket Opened");
                    isConnected = true;
                    
                    // Send initial messages
                    send("{\"protocol\":\"json\",\"version\":1}\u001e");
                    send("{\"arguments\":[{\"activity\":30,\"account\":1065476757}],\"invocationId\":\"0\",\"target\":\"Account\",\"type\":1}\u001e");
                    
                    if (listener != null) {
                        listener.onWebSocketOpen();
                    }
                }

                @Override
                public void onMessage(String message) {
                    Log.d(TAG, "Received: " + message);
                    
                    if (message.length() > 0) {
                        message = message.substring(0, message.length() - 1);
                    }
                    
                    if (listener != null) {
                        listener.onWebSocketMessage(message);
                    }
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    Log.d(TAG, "WebSocket Closed: " + reason);
                    isConnected = false;
                    
                    if (listener != null) {
                        listener.onWebSocketClosed(code, reason);
                    }
                }

                @Override
                public void onError(Exception ex) {
                    Log.e(TAG, "WebSocket Error: " + ex.getMessage());
                    isConnected = false;
                    
                    if (listener != null) {
                        listener.onWebSocketError(ex);
                    }
                }
            };
            
            webSocketClient.connect();
            
        } catch (Exception e) {
            Log.e(TAG, "Connection error: " + e.getMessage());
            if (listener != null) {
                listener.onWebSocketError(e);
            }
        }
    }

    public void disconnect() {
        if (webSocketClient != null) {
            webSocketClient.close();
            webSocketClient = null;
        }
        isConnected = false;
    }

    public boolean isConnected() {
        return isConnected && webSocketClient != null && webSocketClient.isOpen();
    }
}